<?php

namespace App\Exports;

use App\Models\Produk;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use DB;

class ProdukExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //return Produk::all();
        $ar_Produk = DB::table('Produk')
        ->join('penjual', 'penjual.id', '=', 'Produk.Penjual_id')
        ->join('jenis', 'jenis.id', '=', 'Produk.jenis_id')
        ->select('Produk.nama','jenis.nama_jenis','Produk.Stok','Produk.Harga',
                'penjual.name','penjual.alamat',)
        ->get();
        return $ar_Produk;
    }

    public function headings(): array
    {
        return ["Nama", "Kategori","Stok","Harga",
                "Distributor","Alamat"];
    }
}
